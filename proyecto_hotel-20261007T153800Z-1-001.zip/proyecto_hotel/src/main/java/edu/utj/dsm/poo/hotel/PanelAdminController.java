package edu.utj.dsm.poo.hotel;

import edu.utj.dsm.poo.hotel.modelo.Actividad;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;

public class PanelAdminController implements Initializable {

    @FXML
    private Label lblNombreHotel;
    @FXML
    private Label lblUsuarioActual;
    @FXML
    private Button btnCerrarSesion;
    @FXML
    private Button btnInicio;
    @FXML
    private Button btnUsuarios;
    @FXML
    private Button btnConfiguracion;
    @FXML
    private VBox panelCentral;
    @FXML
    private Label lblReservasDia;
    @FXML
    private Label lblHabitacionesLibres;

    @FXML
    private TableView<Actividad> tblActividad;
    @FXML
    private TableColumn<Actividad, String> colFechaHora;
    @FXML
    private TableColumn<Actividad, String> colUsuario;
    @FXML
    private TableColumn<Actividad, String> colAccion;

    private ObservableList<Actividad> listaActividades = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        colFechaHora.setCellValueFactory(new PropertyValueFactory<>("fechaHora"));
        colUsuario.setCellValueFactory(new PropertyValueFactory<>("usuario"));
        colAccion.setCellValueFactory(new PropertyValueFactory<>("accion"));

        tblActividad.setItems(listaActividades);

        cargarDatosEjemplo();
    }

    private void cargarDatosEjemplo() {
        registrarActividad("admin", "Inicio de sesión en el sistema");
        registrarActividad("vmeza", "Creación de nueva reservación");
        registrarActividad("recepcion", "Check-in cliente registrado");
        registrarActividad("Juancarlos", "Creacion de nueva reser6vacion");
    }

  
    public void registrarActividad(String usuario, String accion) {
        String fechaActual = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        Actividad nueva = new Actividad(fechaActual, usuario, accion);
        listaActividades.add(nueva);
    }

    @FXML
    private void cerrarSesion(ActionEvent event) {
    }
}